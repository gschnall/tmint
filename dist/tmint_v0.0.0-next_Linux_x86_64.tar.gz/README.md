# tmint
Interface for managing Tmux sessions, windows, and panes.
